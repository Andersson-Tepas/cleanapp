package com.esfe.cleanapp.application.usecase;

public class RegistrarClienteService {
}
