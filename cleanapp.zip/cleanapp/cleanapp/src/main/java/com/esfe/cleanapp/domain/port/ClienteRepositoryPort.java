package com.esfe.cleanapp.domain.port;

public class ClienteRepositoryPort {
}
