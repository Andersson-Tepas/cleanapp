package com.esfe.cleanapp.infrastructure.persistencia;

public class ClienteRepositoryAdapter {
}
