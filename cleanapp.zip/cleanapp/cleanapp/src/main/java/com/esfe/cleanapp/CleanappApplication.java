package com.esfe.cleanapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CleanappApplication {

	public static void main(String[] args) {
		SpringApplication.run(CleanappApplication.class, args);
	}

}
