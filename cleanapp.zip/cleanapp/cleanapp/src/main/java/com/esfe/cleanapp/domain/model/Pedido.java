package com.esfe.cleanapp.domain.model;

public class Pedido {
}
