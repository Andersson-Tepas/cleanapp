package com.esfe.cleanapp.infrastructure.web;

public class ClienteController {
}
