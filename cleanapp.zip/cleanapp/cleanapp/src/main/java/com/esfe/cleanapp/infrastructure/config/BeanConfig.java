package com.esfe.cleanapp.infrastructure.config;

public class BeanConfig {
}
